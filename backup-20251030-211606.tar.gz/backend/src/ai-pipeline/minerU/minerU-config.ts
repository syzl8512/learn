import { MinerUConfig } from './types';

/**
 * MinerU ؤMn
 */
export const DEFAULT_MINERU_CONFIG: MinerUConfig = {
  apiKey: process.env.MINERU_API_KEY || '',
  apiBaseUrl: process.env.MINERU_API_BASE_URL || 'https://mineru.net/api/v4',
  enableFormula: true,
  enableTable: true,
  enableOCR: true,
  language: 'ch',
  timeout: 600000, // 10 �
  maxRetries: 3,
  pollingInterval: 5000, // 5 �
};

/**
 * PDF ؤMn
 */
export const DEFAULT_PDF_PROCESSING_CONFIG = {
  outputDir: process.env.PDF_OUTPUT_DIR || './storage/pdf-output',
  tempDir: process.env.PDF_TEMP_DIR || './storage/pdf-temp',
  keepTempFiles: false,
  extractImages: true,
};

/**
 * ��'P6(W�)
 */
export const FILE_SIZE_LIMITS = {
  /**  '��': 100MB */
  MAX_FILE_SIZE: 100 * 1024 * 1024,
  /**  ��': 1KB */
  MIN_FILE_SIZE: 1024,
};

/**
 * /���{�
 */
export const SUPPORTED_FILE_TYPES = {
  PDF: ['.pdf'],
  ALL: ['.pdf'],
};

/**
 * ��Mn
 */
export const TIMEOUT_CONFIG = {
  /** 
 ��(��) */
  UPLOAD_TIMEOUT: 120000, // 2 �
  /** ��(��) */
  PROCESSING_TIMEOUT: 600000, // 10 �
  /** }��(��) */
  DOWNLOAD_TIMEOUT: 120000, // 2 �
};

/**
 * ��Mn
 */
export const RETRY_CONFIG = {
  /**  '��!p */
  MAX_RETRIES: 3,
  /** ����(��) */
  RETRY_DELAY: 2000,
  /** ����
��P */
  RETRY_BACKOFF_FACTOR: 2,
};
