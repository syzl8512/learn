/**
 * MinerU PDF {��I
 */

/**
 * PDF lbӜ
 */
export interface PDFConversionResult {
  /** lb� Markdown �� */
  markdown: string;
  /** �� JSON pn */
  contentJson?: any;
  /** @ JSON pn */
  layoutJson?: any;
  /** �ք�Gh */
  images?: ImageInfo[];
  /** Cpn */
  metadata: ConversionMetadata;
}

/**
 * �G�o
 */
export interface ImageInfo {
  /** �G� */
  path: string;
  /** �G URL */
  url?: string;
  /** �G(�c-�Mn */
  position?: number;
  /** �G'(W�) */
  size?: number;
}

/**
 * lbCpn
 */
export interface ConversionMetadata {
  /** �ˇ�
   */
  originalFileName: string;
  /** ��'(W�) */
  fileSize: number;
  /** lb ��� */
  startTime: Date;
  /** lb�_�� */
  endTime: Date;
  /** lb�(��) */
  duration: number;
  /** lb� */
  status: 'success' | 'failed' | 'partial';
  /** ��o */
  error?: string;
  /** up */
  pageCount?: number;
  /** W&p */
  characterCount?: number;
}

/**
 * MinerU API ͔ - ��
  URL
 */
export interface MinerUUploadUrlResponse {
  code: number;
  msg: string;
  data: {
    batch_id: string;
    file_urls: string[];
  };
}

/**
 * MinerU API ͔ - ���
 */
export interface MinerUTaskStatusResponse {
  code: number;
  msg: string;
  data: {
    extract_result: MinerUTaskInfo[];
  };
}

/**
 * MinerU ���o
 */
export interface MinerUTaskInfo {
  file_name: string;
  state: 'pending' | 'processing' | 'done' | 'failed';
  err_msg?: string;
  full_zip_url?: string;
  progress?: number;
}

/**
 * MinerU Mn	y
 */
export interface MinerUConfig {
  /** API Key */
  apiKey: string;
  /** API �@ URL */
  apiBaseUrl: string;
  /** /&/(l�+ */
  enableFormula?: boolean;
  /** /&/(h<�+ */
  enableTable?: boolean;
  /** /&/( OCR */
  enableOCR?: boolean;
  /** �  */
  language?: 'ch' | 'en';
  /** ����(��) */
  timeout?: number;
  /** ��!p */
  maxRetries?: number;
  /** n���(��) */
  pollingInterval?: number;
}

/**
 * PDF 	y
 */
export interface PDFProcessingOptions {
  /** ���U */
  outputDir: string;
  /** 4��U */
  tempDir?: string;
  /** /&�Y4��� */
  keepTempFiles?: boolean;
  /** /&���G */
  extractImages?: boolean;
  /** MinerU Mn */
  minerUConfig?: Partial<MinerUConfig>;
}
