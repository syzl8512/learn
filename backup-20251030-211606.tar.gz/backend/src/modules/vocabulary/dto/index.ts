export * from './create-vocabulary.dto';
export * from './update-vocabulary.dto';
export * from './query-vocabulary.dto';
