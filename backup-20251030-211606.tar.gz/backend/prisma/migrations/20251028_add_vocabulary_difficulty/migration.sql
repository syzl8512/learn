-- CreateTable
CREATE TABLE "vocabulary_difficulty" (
    "id" TEXT NOT NULL,
    "word" TEXT NOT NULL,
    "difficulty" TEXT NOT NULL,
    "lexileLevel" INTEGER NOT NULL,
    "frequency" DOUBLE PRECISION NOT NULL,
    "isCommon" BOOLEAN NOT NULL DEFAULT false,
    "category" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "vocabulary_difficulty_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "vocabulary_difficulty_word_key" ON "vocabulary_difficulty"("word");

-- CreateIndex
CREATE INDEX "vocabulary_difficulty_word_idx" ON "vocabulary_difficulty"("word");

-- CreateIndex
CREATE INDEX "vocabulary_difficulty_difficulty_idx" ON "vocabulary_difficulty"("difficulty");

-- CreateIndex
CREATE INDEX "vocabulary_difficulty_lexileLevel_idx" ON "vocabulary_difficulty"("lexileLevel");
